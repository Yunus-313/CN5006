console.log("This is my first programme!!")
console.log("Welcome Yunus, you made $88,000 last year")
const num1 = 10;
const num2 = 2;
const sum = (num1 + num2);//Adding two numbers
//Programme to output sum of two numbers
console.log("The sum of " + num1 + " " + num2 + " is: " + sum )

console.log(num1 + " divided by " + num2 + " is " + (num1/num2))
console.log(num1 + " multiplied by " + num2 + " is " + (num1*num2))
console.log(num1 + " + " + num2 + " is " + (num1 + num2))
console.log(num1 + " minus " + num2 + " is " + (num1 - num2))



