import java.util.Stack;

public class friendStack {
    // Creating a Stack
    public static void main(String[] args) {
        Stack<String> myFriends = new Stack<>();
        // Pushing new items to the Stack
        myFriends.push("Mohamed");
        myFriends.push("Jamahli");
        myFriends.push("Yunus");
        myFriends.push("Ben");
        myFriends.push("Ali");

        System.out.println("Stack=> " + myFriends);
        System.out.println();

        // Popping items from the Stack
        String friendAtTop = myFriends.pop();
        ; // Throws EmptyStackException if the stack is empty
        System.out.println("Stack.pop() => " + friendAtTop);
        System.out.println("Stack now => " + myFriends);
        System.out.println();

        // Get the item at the top of the stack without removing it
        friendAtTop = myFriends.peek();
        System.out.println("Stack.peek() => " + friendAtTop);
        System.out.println("Current Stack => " + myFriends);

    }
}