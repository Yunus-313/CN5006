import java.util.Stack;

//Part 1
public class StackWithArray {
    private final int[] arr;
    private int top;
    private final int capacity;

    // Constructor to initialize stack
    StackWithArray(int size) {
        arr = new int[size]; // assigning value 'size' to array
        capacity = size; // capacity is always how much the arr can hold
        top = -1; // top is the variable showing arr holds nothing(null)
    }

    // Part 2
    // method adds an element x to the stack
    public void push(int x) {
        if (isFull()) {
            System.out.println("OverFlow\nProgram Terminated\n");
            System.exit(1);
        }
        System.out.println("Inserting " + x);
        arr[++top] = x;
    } // Utility function to pop top element from the stack

    public int pop() {
        // check for stack underflow
        if (isEmpty()) {
            System.out.println("UnderFlow\nProgram Terminated");
            System.exit(1);
        }
        System.out.println("Removing " + peek());
        // decrease stack size by 1 and (optionally) return the popped element
        return arr[top--];
    }

    // Part 3
    // method to return top element in a stack
    public int peek() {
        if (!isEmpty())
            return arr[top];
        else
            System.exit(1);
        return -1;
    }

    // Utility function to return the size of the stack
    public int size() {
        return top + 1;
    }

    // method to check if the stack is empty
    public boolean isEmpty() {
        return top == -1;
        // or return size() == 0;
    }

    // method to check if the stack is full or not
    public boolean isFull() {
        return top == capacity - 1;
    }

    // Part 4
    public static void main(String[] args) {
        Stack stack = new Stack();
        stack.push(1); // Inserting 1 in the stack
        stack.push(2); // Inserting 2 in the stack
        stack.push(12); // Inserting 12 in the stack
        stack.push(53); // Inserting 53 in the stack
        stack.pop(); // removing the top value 53 from the stack
        stack.pop(); // removing the top value 12 from the stack
        stack.push(3); // Inserting 3 in the stack
        System.out.println("Top element is: " + stack.peek());
        System.out.println("Stack size is " + stack.size());
        stack.pop(); // removing the top 3
        // check if stack is empty
        if (stack.isEmpty())
            System.out.println("Stack Is Empty");
        else
            System.out.println("Stack Is Not Empty");
    }
}
